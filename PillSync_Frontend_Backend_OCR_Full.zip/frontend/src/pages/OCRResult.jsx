import { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { CheckCircle2, Loader2, ArrowLeft, Plus } from "lucide-react";
import { runOCR } from "../services/ocrService";
import { addMedicine } from "../services/medicineService";

export default function OCRResult() {
  const location = useLocation();
  const navigate = useNavigate();

  const file = location.state?.file;
  const preview = location.state?.preview;

  const [medicines, setMedicines] = useState([]);
  const [loading, setLoading] = useState(true);
  const [adding, setAdding] = useState(null);
  const [added, setAdded] = useState([]);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!file) {
      navigate("/medicine-upload", { replace: true });
      return;
    }

    async function processPrescription() {
      try {
        setLoading(true);
        setError("");
        const result = await runOCR(file);
        setMedicines(result.medicines || []);
      } catch (err) {
        setError(
          err?.response?.data?.error ||
          "Could not process the prescription. Make sure the backend and Tesseract are running."
        );
      } finally {
        setLoading(false);
      }
    }

    processPrescription();
  }, [file, navigate]);

  const handleAdd = async (medicine, index) => {
    try {
      setAdding(index);
      setError("");
      await addMedicine(medicine.name);
      setAdded((current) => [...current, index]);
    } catch (err) {
      setError(
        err?.response?.data?.detail ||
        err?.response?.data?.error ||
        "Could not add medicine."
      );
    } finally {
      setAdding(null);
    }
  };

  return (
    <div className="min-h-screen">
      <header className="bg-white border-b border-slate-200 px-6 py-4">
        <div className="max-w-5xl mx-auto flex items-center">
          <button
            onClick={() => navigate("/medicine-upload")}
            className="mr-4 text-slate-600 hover:text-slate-900"
          >
            <ArrowLeft size={20} />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-slate-900">PillSync</h1>
            <p className="text-sm text-slate-500">OCR Result</p>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-6 py-10">
        <h2 className="text-3xl font-bold text-slate-900">Detected Medicine</h2>
        <p className="mt-2 text-slate-500">
          Review the medicine detected from your prescription and add it.
        </p>

        {preview && (
          <div className="mt-8 bg-white rounded-2xl p-5 border border-slate-200">
            <p className="font-semibold text-slate-800 mb-3">Prescription</p>
            <img
              src={preview}
              alt="Uploaded prescription"
              className="max-h-60 rounded-xl object-contain"
            />
          </div>
        )}

        {loading && (
          <div className="mt-8 bg-white rounded-2xl p-10 border border-slate-200 text-center">
            <Loader2 className="mx-auto animate-spin text-indigo-600" size={34} />
            <p className="mt-4 text-slate-600">Reading prescription...</p>
          </div>
        )}

        {!loading && !error && medicines.length === 0 && (
          <div className="mt-8 bg-white rounded-2xl p-10 border border-slate-200 text-center">
            <p className="font-semibold text-slate-800">No medicine was detected.</p>
            <p className="mt-2 text-sm text-slate-500">
              Try a clearer prescription image.
            </p>
          </div>
        )}

        {!loading && medicines.length > 0 && (
          <div className="mt-8 space-y-4">
            {medicines.map((medicine, index) => (
              <div
                key={`${medicine.name}-${index}`}
                className="bg-white rounded-2xl border border-slate-200 p-5 flex items-center justify-between"
              >
                <div>
                  <p className="text-lg font-semibold text-slate-900">
                    {medicine.name}
                  </p>
                  <p className="text-sm text-slate-500 mt-1">
                    Detected by OCR
                  </p>
                </div>

                {added.includes(index) ? (
                  <div className="flex items-center gap-2 text-green-600 font-semibold">
                    <CheckCircle2 size={20} />
                    Added
                  </div>
                ) : (
                  <button
                    disabled={adding === index}
                    onClick={() => handleAdd(medicine, index)}
                    className="rounded-xl bg-indigo-600 text-white px-5 py-2.5 font-semibold flex items-center gap-2 hover:bg-indigo-700 disabled:opacity-60"
                  >
                    {adding === index ? (
                      <Loader2 className="animate-spin" size={18} />
                    ) : (
                      <Plus size={18} />
                    )}
                    Add Medicine
                  </button>
                )}
              </div>
            ))}
          </div>
        )}

        {error && (
          <div className="mt-6 rounded-xl bg-red-50 border border-red-200 p-4 text-sm text-red-700">
            {error}
          </div>
        )}
      </main>
    </div>
  );
}
