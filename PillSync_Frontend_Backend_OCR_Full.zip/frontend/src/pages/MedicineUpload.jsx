import { useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Upload, FileText, ArrowRight } from "lucide-react";

export default function MedicineUpload() {
  const fileInputRef = useRef(null);
  const navigate = useNavigate();
  const [file, setFile] = useState(null);
  const [preview, setPreview] = useState("");
  const [error, setError] = useState("");

  const handleFile = (selectedFile) => {
    if (!selectedFile) return;

    if (!selectedFile.type.startsWith("image/")) {
      setError("Please select an image file.");
      return;
    }

    setError("");
    setFile(selectedFile);
    setPreview(URL.createObjectURL(selectedFile));
  };

  const continueToOCR = () => {
    if (!file) {
      setError("Please upload a prescription first.");
      return;
    }

    navigate("/ocr-result", {
      state: {
        file,
        preview,
      },
    });
  };

  return (
    <div className="min-h-screen">
      <header className="bg-white border-b border-slate-200 px-6 py-4">
        <div className="max-w-5xl mx-auto flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-slate-900">PillSync</h1>
            <p className="text-sm text-slate-500">Prescription & Medicine</p>
          </div>
          <span className="text-sm text-slate-500">Medicine Upload</span>
        </div>
      </header>

      <main className="max-w-3xl mx-auto px-6 py-12">
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-slate-900">Upload Prescription</h2>
          <p className="mt-2 text-slate-500">
            Upload a prescription image and PillSync will read the medicine name.
          </p>
        </div>

        <div
          onClick={() => fileInputRef.current?.click()}
          className="bg-white rounded-2xl border-2 border-dashed border-slate-300 p-12 text-center hover:border-indigo-400 transition"
        >
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={(e) => handleFile(e.target.files?.[0])}
          />

          {preview ? (
            <div>
              <img
                src={preview}
                alt="Prescription preview"
                className="mx-auto max-h-72 rounded-xl object-contain"
              />
              <p className="mt-4 text-sm text-slate-600">{file?.name}</p>
            </div>
          ) : (
            <>
              <div className="mx-auto w-16 h-16 rounded-full bg-indigo-50 flex items-center justify-center">
                <Upload className="text-indigo-600" size={30} />
              </div>
              <h3 className="mt-5 text-lg font-semibold text-slate-800">
                Upload prescription image
              </h3>
              <p className="mt-2 text-sm text-slate-500">
                Click here to choose an image from your computer.
              </p>
            </>
          )}
        </div>

        {error && (
          <p className="mt-4 text-sm text-red-600">{error}</p>
        )}

        <button
          onClick={continueToOCR}
          className="mt-6 w-full rounded-xl bg-indigo-600 text-white py-3.5 font-semibold flex items-center justify-center gap-2 hover:bg-indigo-700"
        >
          Continue <ArrowRight size={18} />
        </button>

        <div className="mt-6 flex items-center gap-3 text-sm text-slate-500">
          <FileText size={18} />
          <span>Only the prescription image is sent for OCR.</span>
        </div>
      </main>
    </div>
  );
}
