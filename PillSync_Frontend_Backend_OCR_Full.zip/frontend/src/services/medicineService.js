import api from "./api";

export async function addMedicine(name) {
  const response = await api.post("/medications/", { name });
  return response.data;
}
