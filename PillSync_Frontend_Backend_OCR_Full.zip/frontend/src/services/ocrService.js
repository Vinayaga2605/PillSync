import api from "./api";

export async function runOCR(file) {
  const formData = new FormData();
  formData.append("prescription", file);

  const response = await api.post("/ocr/", formData, {
    headers: {
      "Content-Type": "multipart/form-data",
    },
  });

  return response.data;
}
