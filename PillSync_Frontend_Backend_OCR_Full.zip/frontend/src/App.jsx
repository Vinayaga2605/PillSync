import { BrowserRouter, Navigate, Route, Routes } from "react-router-dom";
import MedicineUpload from "./pages/MedicineUpload";
import OCRResult from "./pages/OCRResult";

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Navigate to="/medicine-upload" replace />} />
        <Route path="/medicine-upload" element={<MedicineUpload />} />
        <Route path="/ocr-result" element={<OCRResult />} />
      </Routes>
    </BrowserRouter>
  );
}
