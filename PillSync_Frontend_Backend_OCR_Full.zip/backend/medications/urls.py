from django.urls import path
from .views import MedicationListCreateView

urlpatterns = [
    path("medications/", MedicationListCreateView.as_view(), name="medications"),
]
