from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView

from .models import Medication
from .serializers import MedicationSerializer

class MedicationListCreateView(APIView):
    def get(self, request):
        medicines = Medication.objects.order_by("-created_at")
        return Response(MedicationSerializer(medicines, many=True).data)

    def post(self, request):
        serializer = MedicationSerializer(data=request.data)
        if serializer.is_valid():
            medicine = serializer.save()
            return Response(
                MedicationSerializer(medicine).data,
                status=status.HTTP_201_CREATED
            )
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
