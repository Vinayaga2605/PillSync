import re
import pytesseract

from PIL import Image, ImageOps, ImageEnhance
from rest_framework.parsers import MultiPartParser, FormParser
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework import status


# Common prescription words are removed so the demo can focus on medicine-like
# text. This is intentionally simple and can later be replaced by an ML/NLP model.
STOP_WORDS = {
    "rx", "prescription", "patient", "name", "age", "date",
    "doctor", "dr", "take", "tablet", "tab", "capsule", "cap",
    "syrup", "mg", "ml", "once", "twice", "daily", "morning",
    "afternoon", "night", "before", "after", "food", "with",
    "days", "day", "for", "times", "qty", "quantity"
}

class OCRView(APIView):
    parser_classes = [MultiPartParser, FormParser]

    def post(self, request):
        uploaded = request.FILES.get("prescription")

        if not uploaded:
            return Response(
                {"error": "Please upload a prescription image."},
                status=status.HTTP_400_BAD_REQUEST
            )

        try:
            image = Image.open(uploaded).convert("L")
            image = ImageOps.autocontrast(image)
            image = ImageEnhance.Contrast(image).enhance(1.5)

            raw_text = pytesseract.image_to_string(image)

            medicines = self.extract_medicines(raw_text)

            return Response({
                "medicines": [{"name": name} for name in medicines],
                "raw_text": raw_text.strip(),
            })

        except Exception as exc:
            return Response(
                {"error": f"OCR failed: {str(exc)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

    @staticmethod
    def extract_medicines(text):
        candidates = []

        for line in text.splitlines():
            line = re.sub(r"[^A-Za-z0-9 .+/-]", " ", line)
            line = re.sub(r"\s+", " ", line).strip()

            if not line:
                continue

            # Remove obvious dosage/schedule-only fragments.
            words = line.split()
            meaningful = [
                word for word in words
                if word.lower().strip(".") not in STOP_WORDS
            ]

            if not meaningful:
                continue

            # Ignore very short numeric-only OCR noise.
            if all(re.fullmatch(r"\d+(?:\.\d+)?", w) for w in meaningful):
                continue

            candidate = " ".join(meaningful)

            # Strip common dosage suffixes from the display name.
            candidate = re.sub(
                r"\b\d+(?:\.\d+)?\s*(mg|mcg|g|ml)\b",
                "",
                candidate,
                flags=re.I
            ).strip()

            if len(candidate) >= 3:
                candidates.append(candidate)

        # Preserve order while removing duplicates.
        unique = []
        seen = set()
        for item in candidates:
            key = item.lower()
            if key not in seen:
                seen.add(key)
                unique.append(item)

        return unique[:10]
