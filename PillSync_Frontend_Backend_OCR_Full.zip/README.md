# PillSync — OCR → Medicine Full Demo

This package contains a minimal end-to-end version of the PillSync flow requested:

Upload prescription image
→ OCR reads the image
→ extracted medicine name(s) are shown
→ click Add Medicine
→ medicine is stored through the Django REST API

## Included
- `frontend/` React + Vite + Tailwind frontend
- `backend/` Django REST Framework backend
- OCR endpoint using Tesseract via `pytesseract`
- Medicine create/list API
- CORS configuration
- Simple SQLite development database

## Important
This is intentionally kept minimal. It does NOT implement:
- reminders
- push notifications
- expiry dates
- refill prediction
- analytics
- medication history
- complex dosage scheduling

The OCR backend uses Tesseract. Handwritten prescriptions may require a stronger OCR/model later.

## 1. Backend

Requirements:
- Python 3.10+
- Tesseract OCR installed on your computer

macOS:
```bash
brew install tesseract
```

Then:
```bash
cd backend
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python manage.py migrate
python manage.py runserver
```

Backend:
`http://127.0.0.1:8000`

OCR API:
`POST http://127.0.0.1:8000/api/ocr/`

Medicine API:
`POST http://127.0.0.1:8000/api/medications/`
`GET  http://127.0.0.1:8000/api/medications/`

## 2. Frontend

Open another terminal:
```bash
cd frontend
npm install
npm run dev
```

Open the Vite URL shown in the terminal, normally:
`http://localhost:5173`

## 3. Demo flow

1. Open Medicine Upload.
2. Click Upload Prescription.
3. Select a prescription image.
4. Click Continue.
5. Frontend sends the image to `/api/ocr/`.
6. OCR results are displayed.
7. Click Add Medicine.
8. Frontend sends the selected medicine to `/api/medications/`.
9. Backend stores it in SQLite.

## API response expected from OCR

```json
{
  "medicines": [
    {
      "name": "Metformin"
    }
  ],
  "raw_text": "Metformin 500 mg..."
}
```

The frontend is deliberately written so the OCR response can later be replaced by your team's actual OCR/AI endpoint without changing the medicine-add flow.
